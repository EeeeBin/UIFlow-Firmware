### v1.5.1

* Fixed: SD card error
* Fixed: Remote Error

* Update: Mqtt can run in exec mode
* Add: Mqtt add last will support (must be ahead in mqtt start)
* Add: ENV-II unit support
* Add: I2C add data different format